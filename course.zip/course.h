/**
 * @file course.h
 * @author Azzam Baig
 * @date 2022-04-12
 * @brief Course library for managing courses, including course type definition
 *        and course functions. 
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * Course type stores a course with fields name, code, and total number of students enrolled in the course.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< The course name*/
  char code[10]; /**< The course code */
  Student *students; /**< Pointer to the dynamically allocated array that contains all the students enrolled in the course */
  int total_students; /**< The total number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


