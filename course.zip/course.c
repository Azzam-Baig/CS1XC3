/**
 * @file course.c
 * @author Azzam Baig
 * @date 2022-04-12
 * @brief Course library for managing courses, including definitions of Course
 *        functions.
 * 
 * @version 0.1
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Dynamically allocates an array for students enrolled in the course and 
 * then adds the given student to the array.
 * 
 * Initially, when the total number of students in the course is 1, calloc is
 * used to allocated just enough space for a single student.
 * However, once the total number of students in the course is greater than 1,
 * realloc is used to re-allocate additional space.
 * 
 * @param course a pointer to the course
 * @param student a pointer to the student
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the course's name, code, total number of students,
 * and each student enrolled in the course.
 * 
 * @param course a pointer to the course
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Traverses through the dynamic array of students enrolled in the given course,
 * then calculates and returns the student with the highest average grade.
 * 
 * @param course a pointer to the course
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // loops through the dynamic array of students and continuously compares
  // the averages until it find the student with the maximum average grade.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * Traverses through the dynamic array of students, checks if their averages are above 50
 * then returns a dynamic array containing all the passing students.
 * 
 * @param course A pointer to the course
 * @param total_passing A pointer to the total number of students that will pass
 * @return Student* a pointer to a dynamically allocated array that contains
 *         all the passing students
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // loops through the dynamic array of students and if their average grade is
  // greater than 50, then increment count
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  

  passing = calloc(count, sizeof(Student));

  // adds all the students with average grades greater than 50 to the dynamic array 
  // that contains all the passing students
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}