/**
 * @file student.h
 * @author Azzam Baig
 * @date 2022-04-12
 * @brief Student library for managing students, including student type definition
 *        and student functions.
 * 
 */

/**
 * Student type stores a student with fields first name, last name, student id, grades, and number of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< The student's first name */
  char last_name[50]; /**< The student's last name */
  char id[11]; /**< The student's id */
  double *grades; /**< A pointer to the dynamically allocated array that contains the student's grades */
  int num_grades; /**< The number of courses the student is enrolled in that have grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
