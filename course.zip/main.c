/**
 * @mainpage Course and Student function demonstration
 * 
 * The course and student function demonstration shows how multiple functions
 * in the course and student libraries work, including:
 * - Enrolling a student in a course
 * - Generating a random student
 * - Printing a course
 * - Finding the top student in a course
 * - Printing a student
 * - Finding the students that will pass a course
 * 
 * @file main.c
 * @author Azzam Baig
 * @date 2022-04-12
 * @brief Runs demonstration code for course and student library methods.
 * @version 0.1
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates a dynamically allocated course and tests the course library methods for enrolling 
 * a student, printing a course, finding the top student, and finding the passing students. 
 * Additionally, it tests the student library methods for generating and printing a student.
 * 
 * 
 */
int main()
{
  srand((unsigned) time(NULL));

  // Creates a course 
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // Generates and enrolls 20 students into the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  // Prints the course 
  print_course(MATH101);

  // Find and prints the top student in the course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Returns the total number of passing students in the course
  // and returns the passing students themselves
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}